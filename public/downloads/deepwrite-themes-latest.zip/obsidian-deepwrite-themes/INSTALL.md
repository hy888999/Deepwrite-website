# DeepWrite Themes 手动安装指南（面向新手）

这份文档会先解释你在做什么，再带你一步一步完成安装。

## 先理解 3 个概念

1. **Obsidian 是应用程序**
   - 就是你用来写笔记的软件。

2. **Vault 是你的笔记库文件夹**
   - 你在 Obsidian 里看到的一整套笔记，底层对应磁盘上的一个目录。
   - 你可以有多个 Vault，它们互相独立。

3. **插件要装在 Vault 里，不是装在 Obsidian 程序目录里**
   - Obsidian 只会在这个固定位置扫描插件：
   - `.obsidian/plugins/obsidian-deepwrite-themes/`

## 为什么要放到隐藏目录 `.obsidian`

- `.obsidian` 是每个 Vault 的配置目录，用来保存插件、主题、快捷键等设置。
- 它以点号开头，所以在 macOS Finder 里默认隐藏。
- 你可以按 `Cmd + Shift + .` 显示/隐藏它。

## 安装前准备

下载并解压安装包后，确认至少有这两个文件：

- `main.js`
- `manifest.json`

（`versions.json` 可有可无，不影响手动安装）

## 手动安装步骤（推荐按顺序做）

1. 打开 Obsidian，进入你要安装插件的 Vault。
2. 找到该 Vault 的根目录（可在 Obsidian 里使用“在 Finder 中显示”）。
3. 在 Finder 中按 `Cmd + Shift + .`，显示隐藏目录。
4. 进入（或创建）目录：
   - `.obsidian/plugins/obsidian-deepwrite-themes/`
5. 将 `main.js` 与 `manifest.json` 复制到该目录。
6. 回到 Obsidian：
   - 设置 → 第三方插件
   - 关闭安全模式（若尚未关闭）
   - 启用 **DeepWrite Themes**

## 验证是否安装成功

启用后你可以看到：

- 设置页面里出现 DeepWrite Themes
- 命令面板可搜索：`Select Color Scheme (配色模式选择)`
- 默认快捷键可用：`Cmd/Ctrl + Shift + K`

## 新手常见问题

### Q1：我看不到 `.obsidian` 目录
A：在 Finder 按 `Cmd + Shift + .`，即可显示隐藏文件。

### Q2：复制了文件，但第三方插件里看不到
A：通常是路径放错了。请确认你复制的是“目标 Vault 内”的：
`.obsidian/plugins/obsidian-deepwrite-themes/`

### Q3：我有多个 Vault，要装几次？
A：需要分别安装。插件按 Vault 生效，不会自动同步到其他 Vault。

### Q4：这个插件会替换我当前主题吗？
A：不会。它只调整 Markdown 语义配色，不会替换 Obsidian 主题框架。

## 升级插件

新版发布后，重复上述复制步骤，用新版本覆盖：

- `main.js`
- `manifest.json`

然后在 Obsidian 中禁用再启用插件，或重启 Obsidian。
