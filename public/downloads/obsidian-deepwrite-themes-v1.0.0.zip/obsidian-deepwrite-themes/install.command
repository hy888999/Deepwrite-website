#!/bin/zsh
set -euo pipefail

PLUGIN_ID="obsidian-deepwrite-themes"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

SOURCE_MAIN="$SCRIPT_DIR/main.js"
SOURCE_MANIFEST="$SCRIPT_DIR/manifest.json"
SOURCE_VERSIONS="$SCRIPT_DIR/versions.json"
SOURCE_STYLES="$SCRIPT_DIR/styles.css"

if [[ ! -f "$SOURCE_MAIN" || ! -f "$SOURCE_MANIFEST" ]]; then
  echo "❌ 未找到 main.js 或 manifest.json"
  echo "请确保 install.command 与插件构建产物在同一目录。"
  read -k "REPLY?按任意键退出..."
  echo
  exit 1
fi

echo "========================================="
echo "DeepWrite Themes 一键安装"
echo "========================================="
echo
echo "📌 提示：Obsidian 插件目录是隐藏目录（.obsidian）。"
echo "   在 Finder 可按 Cmd + Shift + . 显示隐藏文件。"
echo

print_security_help() {
  echo "如果 macOS 提示“无法打开”或“已损坏”，可在终端执行："
  echo "  xattr -dr com.apple.quarantine \"$(pwd)\""
  echo "  chmod +x \"$(pwd)/install.command\""
  echo "  ./install.command"
  echo
}

list_vaults() {
  local -a roots
  local -a results
  local root
  local entry

  roots=(
    "$HOME/Library/Mobile Documents/iCloud~md~obsidian/Documents"
    "$HOME/Documents"
  )

  for root in "${roots[@]}"; do
    [[ -d "$root" ]] || continue
    for entry in "$root"/*; do
      [[ -d "$entry" ]] || continue
      [[ -d "$entry/.obsidian" ]] || continue
      results+=("$entry")
    done
  done

  # 去重
  typeset -A seen
  local -a unique
  for entry in "${results[@]}"; do
    if [[ -z "${seen[$entry]-}" ]]; then
      seen[$entry]=1
      unique+=("$entry")
    fi
  done

  printf "%s\n" "${unique[@]}"
}

choose_vault() {
  local -a candidates
  local entry
  local i

  echo "请选择安装方式："
  echo "  [1] 自动列出本机 Vault 并选择"
  echo "  [2] 手动输入 Vault 目录（推荐）"
  echo
  echo -n "你的选择（默认 2）: "
  read -r mode
  mode=${mode:-2}

  if [[ "$mode" == "2" ]]; then
    echo "手动输入示例："
    echo "  /Users/<你的用户名>/Library/Mobile Documents/iCloud~md~obsidian/Documents/Hyob"
    echo -n "Vault 路径: "
    read -r manual
    echo "$manual"
    return
  fi

  if [[ "$mode" != "1" ]]; then
    echo "❌ 选择无效" >&2
    exit 1
  fi

  echo
  echo "正在扫描 Vault（通常 1-3 秒）..."
  while IFS= read -r entry; do
    [[ -n "$entry" ]] && candidates+=("$entry")
  done < <(list_vaults)

  if (( ${#candidates[@]} == 0 )); then
    echo "⚠️ 未扫描到 Vault，请改为手动输入路径。"
    echo -n "Vault 路径: "
    read -r manual
    echo "$manual"
    return
  fi

  echo "发现以下 Vault，请输入编号选择："
  i=1
  for entry in "${candidates[@]}"; do
    echo "  [$i] $entry"
    ((i++))
  done
  echo "  [M] 手动输入路径"
  echo
  echo -n "你的选择: "
  read -r choice

  if [[ "${choice:u}" == "M" ]]; then
    echo -n "Vault 路径: "
    read -r manual
    echo "$manual"
    return
  fi

  if [[ "$choice" =~ '^[0-9]+$' ]] && (( choice >= 1 && choice <= ${#candidates[@]} )); then
    echo "${candidates[$choice]}"
  else
    echo "❌ 选择无效" >&2
    exit 1
  fi
}

TARGET_VAULT="${1:-}"
if [[ -z "$TARGET_VAULT" ]]; then
  TARGET_VAULT="$(choose_vault)"
fi

if [[ ! -d "$TARGET_VAULT" ]]; then
  echo "❌ Vault 目录不存在: $TARGET_VAULT"
  print_security_help
  read -k "REPLY?按任意键退出..."
  echo
  exit 1
fi

if [[ ! -d "$TARGET_VAULT/.obsidian" ]]; then
  echo "❌ 该目录不是有效 Obsidian Vault（缺少 .obsidian）: $TARGET_VAULT"
  echo "你可能选择到了子文件夹，请选择 Vault 根目录。"
  echo "Finder 里可按 Cmd + Shift + . 显示隐藏目录后确认。"
  print_security_help
  read -k "REPLY?按任意键退出..."
  echo
  exit 1
fi

TARGET_DIR="$TARGET_VAULT/.obsidian/plugins/$PLUGIN_ID"
mkdir -p "$TARGET_DIR"

cp -f "$SOURCE_MAIN" "$TARGET_DIR/main.js"
cp -f "$SOURCE_MANIFEST" "$TARGET_DIR/manifest.json"
if [[ -f "$SOURCE_VERSIONS" ]]; then
  cp -f "$SOURCE_VERSIONS" "$TARGET_DIR/versions.json"
fi
if [[ -f "$SOURCE_STYLES" ]]; then
  cp -f "$SOURCE_STYLES" "$TARGET_DIR/styles.css"
fi

echo
echo "✅ 安装完成"
echo "目标目录: $TARGET_DIR"
ls -lh "$TARGET_DIR/main.js" "$TARGET_DIR/manifest.json" 2>/dev/null || true

echo
echo "下一步："
echo "1) 打开 Obsidian"
echo "2) 设置 → 第三方插件"
echo "3) 启用 DeepWrite Themes"
echo
echo "若未看到插件："
echo "- 确认目标目录中存在 main.js 与 manifest.json"
echo "- 在 Finder 按 Cmd + Shift + . 显示隐藏目录"
echo "- 或重启 Obsidian 后再查看第三方插件"
echo
read -k "REPLY?按任意键关闭窗口..."
echo
