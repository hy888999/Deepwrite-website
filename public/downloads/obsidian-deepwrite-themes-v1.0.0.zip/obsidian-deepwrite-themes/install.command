#!/bin/zsh
set -euo pipefail

PLUGIN_ID="obsidian-deepwrite-themes"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

SOURCE_MAIN="$SCRIPT_DIR/main.js"
SOURCE_MANIFEST="$SCRIPT_DIR/manifest.json"
SOURCE_VERSIONS="$SCRIPT_DIR/versions.json"
SOURCE_STYLES="$SCRIPT_DIR/styles.css"

if [[ ! -f "$SOURCE_MAIN" || ! -f "$SOURCE_MANIFEST" ]]; then
  echo "❌ 未找到 main.js 或 manifest.json"
  echo "请确保 install.command 与插件构建产物在同一目录。"
  read -k "REPLY?按任意键退出..."
  echo
  exit 1
fi

echo "========================================="
echo "DeepWrite Themes 一键安装"
echo "========================================="
echo

choose_vault() {
  local -a roots
  local -a candidates
  local root
  local entry
  local i

  roots=(
    "$HOME/Library/Mobile Documents/iCloud~md~obsidian/Documents"
    "$HOME/Documents"
  )

  for root in "${roots[@]}"; do
    if [[ -d "$root" ]]; then
      while IFS= read -r -d '' entry; do
        if [[ -d "$entry/.obsidian" ]]; then
          candidates+=("$entry")
        fi
      done < <(find "$root" -mindepth 1 -maxdepth 2 -type d -print0 2>/dev/null)
    fi
  done

  # 去重
  typeset -A seen
  local -a unique
  for entry in "${candidates[@]}"; do
    if [[ -z "${seen[$entry]-}" ]]; then
      seen[$entry]=1
      unique+=("$entry")
    fi
  done

  if (( ${#unique[@]} == 0 )); then
    echo "⚠️ 未自动扫描到 Vault，请手动输入 Vault 目录绝对路径。"
    echo -n "Vault 路径: "
    read -r manual
    echo "$manual"
    return
  fi

  echo "发现以下 Vault，请输入编号选择："
  i=1
  for entry in "${unique[@]}"; do
    echo "  [$i] $entry"
    ((i++))
  done
  echo "  [M] 手动输入路径"
  echo
  echo -n "你的选择: "
  read -r choice

  if [[ "${choice:u}" == "M" ]]; then
    echo -n "Vault 路径: "
    read -r manual
    echo "$manual"
    return
  fi

  if [[ "$choice" =~ '^[0-9]+$' ]] && (( choice >= 1 && choice <= ${#unique[@]} )); then
    echo "${unique[$choice]}"
  else
    echo "❌ 选择无效" >&2
    exit 1
  fi
}

TARGET_VAULT="${1:-}"
if [[ -z "$TARGET_VAULT" ]]; then
  TARGET_VAULT="$(choose_vault)"
fi

if [[ ! -d "$TARGET_VAULT" ]]; then
  echo "❌ Vault 目录不存在: $TARGET_VAULT"
  read -k "REPLY?按任意键退出..."
  echo
  exit 1
fi

if [[ ! -d "$TARGET_VAULT/.obsidian" ]]; then
  echo "❌ 该目录不是有效 Obsidian Vault（缺少 .obsidian）: $TARGET_VAULT"
  read -k "REPLY?按任意键退出..."
  echo
  exit 1
fi

TARGET_DIR="$TARGET_VAULT/.obsidian/plugins/$PLUGIN_ID"
mkdir -p "$TARGET_DIR"

cp -f "$SOURCE_MAIN" "$TARGET_DIR/main.js"
cp -f "$SOURCE_MANIFEST" "$TARGET_DIR/manifest.json"
if [[ -f "$SOURCE_VERSIONS" ]]; then
  cp -f "$SOURCE_VERSIONS" "$TARGET_DIR/versions.json"
fi
if [[ -f "$SOURCE_STYLES" ]]; then
  cp -f "$SOURCE_STYLES" "$TARGET_DIR/styles.css"
fi

echo
echo "✅ 安装完成"
echo "目标目录: $TARGET_DIR"
ls -lh "$TARGET_DIR/main.js" "$TARGET_DIR/manifest.json" 2>/dev/null || true

echo
echo "下一步："
echo "1) 打开 Obsidian"
echo "2) 设置 → 第三方插件"
echo "3) 启用 DeepWrite Themes"
echo
read -k "REPLY?按任意键关闭窗口..."
echo
