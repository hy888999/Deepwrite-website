# Obsidian DeepWrite Export - 安装指南（最新）

## 环境准备

```bash
cd /Users/hongyi/CodeBuddy/obsidian-deepwrite-export
npm install
npm run build
```

## 安装到 Obsidian Vault

```bash
mkdir -p "/path/to/vault/.obsidian/plugins/deepwrite-export"
cp main.js manifest.json "/path/to/vault/.obsidian/plugins/deepwrite-export/"
```

在 Obsidian 中启用：
- 设置 → 第三方插件 → DeepWrite Export

## 推荐部署方式

### 1) 快速部署到指定 Vault（推荐）

```bash
./quick-deploy.sh Hyob
```

### 2) 发布流程（含自检）

```bash
npm run release
# 或
./release.sh --vault Hyob
```

## 常用命令

```bash
npm run build        # 构建
npm run self-check   # 发布前自检
npm run release      # 自检 + 构建 + 部署
```

## 外部授权工具（已迁出仓库时）

若你已将授权工具放到仓库外，可在自检时指定路径：

```bash
LICENSE_CLI_PATH="/abs/path/gen-license.js" \
LICENSE_WEB_PATH="/abs/path/web-license.html" \
npm run self-check
```

说明：
- 不配置也可运行，`self-check` 会给出告警并跳过外部授权工具检查。
- 主插件构建与导出功能不受影响。

## 安装验证

1. 插件在第三方插件列表可见并启用
2. 导出命令可用
3. 导出 HTML 可正常打开
4. 导出页快捷键可用：`F` `T` `H` `Z` `[` `]`

## 常见问题

### 插件没显示
- 检查目录：`.obsidian/plugins/deepwrite-export/`
- 检查文件：`main.js`、`manifest.json`
- 关闭 Obsidian 安全模式后重试

### 页面效果不是最新
- 重新执行 `npm run build`
- 重新复制 `main.js` 与 `manifest.json`
- 在 Obsidian 里重载插件
