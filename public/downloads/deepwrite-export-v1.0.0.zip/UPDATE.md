# 更新记录（最近一次大版本）

## 本次更新重点

### 1) 会员系统重构
- 会员模块独立化，便于复用到其他 Obsidian 插件
- 注册/登录/激活流程增强（邮箱格式、密码强度、状态提示）
- 套餐分级与配额控制：trial/free/normal/pro/super
- `trial-expired` 与 `member-expired` 状态处理完善

### 2) 授权安全升级
- 密码哈希存储
- 授权码 HMAC-SHA256 验签
- 邮箱绑定校验，防止跨账号滥用
- 支持 v1/v2 授权版本与密钥轮换

### 3) 导出页体验升级
- 目录左/右切换
- 移动端目录抽屉自动收起
- 全屏阅读与紧凑小圆点模式
- 目录高亮与滚动优化
- 打印样式增强
- 快捷键：`F` `T` `H` `Z` `[` `]`

### 4) 工程与发布流程升级
- 新增 `self-check.sh`
- 新增 `release.sh`
- `package.json` 增加 `self-check`、`release` 脚本
- `TEST.md` 增加发布回归检查清单

### 5) 授权工具外部化
- 授权生成 CLI 与 Web 页面支持迁出仓库
- 自检支持 `LICENSE_CLI_PATH` / `LICENSE_WEB_PATH` 覆盖路径
- 未配置路径时仅告警，不阻塞主插件构建发布

## 推荐发布命令

```bash
npm run self-check
npm run release
```

## 文档同步情况

本次已同步更新：
- `README.md`
- `INSTALL.md`
- `DEPLOYMENT.md`
- `PROJECT.md`
- `QUICK_REF.md`
- `business-promotion/*`
- `membership/AUTH_SECURITY_GUIDE.md`
