# Obsidian DeepWrite Export Plugin

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Platform](https://img.shields.io/badge/platform-Obsidian-purple.svg)

将 Obsidian 中的 Markdown 导出为带 DeepWrite 风格的 HTML，并提供沉浸式阅读、目录导航、快捷键、会员配额控制与授权体系。

</div>

---

## ✨ 当前核心能力

### 1) 导出能力
- 单篇导出：当前笔记导出为独立 HTML
- 批量导出：支持选择源/目标文件夹批量导出
- 多入口触发：工具栏、命令面板、右键菜单

### 2) 阅读体验（导出后的 HTML）
- 5 种背景主题 + 20 种阅读配色
- 目录自动生成（H1/H2）
- 目录可切换 **左侧 / 右侧**
- 目录可显示/隐藏，控制区可显示/隐藏
- 移动端目录抽屉：默认隐藏，点击展开；点击正文自动收起
- 全屏阅读按钮（Fullscreen API）
- 当“目录 + 控制区都隐藏”时，右上工具条自动退化为小圆点，悬停展开
- 当前章节目录高亮（滚动同步）
- 打印友好（`@media print`：仅保留正文）
- 可访问性增强（`aria-label`、`focus-visible`）

### 3) 快捷键（导出后的 HTML）
- `F`：全屏切换
- `T`：目录显示/隐藏
- `H`：主题控制区显示/隐藏
- `Z`：深色/浅色主题快速切换
- `[`：目录切到左侧
- `]`：目录切到右侧

### 4) 会员与授权
- 试用、免费、普通/高级/顶级会员配额控制
- 顶级会员可用批量导出
- 授权码支持签名验签（HMAC-SHA256）
- 授权码支持 **v1/v2** 版本兼容与密钥轮换基础

---

## 🚀 快速开始

## 安装与构建

```bash
git clone https://github.com/hy888999/obsidian-deepwrite-export.git
cd obsidian-deepwrite-export
npm install
npm run build
```

## 部署到指定 Vault

```bash
./quick-deploy.sh Hyob
```

或手动复制：

```bash
cp main.js manifest.json "/path/to/vault/.obsidian/plugins/deepwrite-export/"
```

在 Obsidian 中启用插件：
- 设置 → 第三方插件 → DeepWrite Export

---

## 📖 使用指南

## 导出当前笔记
- 工具栏下载图标
- 命令面板：`Export current note as HTML`
- 文件右键：`Export as HTML (DeepWrite)`

## 批量导出
- 命令面板：`Batch export notes to HTML`
- 仅顶级会员可使用批量导出

## 配置项
| 配置项 | 说明 |
|---|---|
| 默认模式 | 导出 HTML 的默认主题模式（Dark/Light） |
| 自动导出路径 | 导出目标文件夹（留空则同目录） |
| 导出后自动打开 | 导出完成后自动打开 HTML |

---

## 🔐 授权与安全（重要）

详细文档请看：
- `membership/AUTH_SECURITY_GUIDE.md`

该文档包含：
- 授权全流程说明
- 当前安全等级评估
- 现存风险与升级策略
- 哪些文件应移出插件模块并独立管理

## 外部授权工具（已支持移出仓库）

当前项目允许将授权生成工具放在仓库外部。默认推荐外部路径：
- `DW EXPORT OUTSIDE DOC/license-tools/gen-license.js`
- `DW EXPORT OUTSIDE DOC/license-tools/web-license.html`

如果你已经移出到其它位置，可在自检时传环境变量：

```bash
LICENSE_CLI_PATH="/abs/path/gen-license.js" \
LICENSE_WEB_PATH="/abs/path/web-license.html" \
npm run self-check
```

---

## 🧪 测试与发布

## 自检

```bash
npm run self-check
```

自检内容包含：
- 构建检查
- 密钥轮换配置检查
- 阅读增强能力检查
- 授权网页关键项检查（若外部工具不存在则告警并跳过）

## 发布

```bash
npm run release
```

可选参数：

```bash
./release.sh --vault Hyob
./release.sh --vault Hyob --tag v1.0.1
./release.sh --vault Hyob --tag v1.0.1 --push-tag
```

---

## 🧭 项目结构（当前）

```text
obsidian-deepwrite-export/
├── src/
│   ├── main.ts                 # 插件入口、命令与设置
│   ├── html-generator.ts       # 导出页模板（主题/目录/快捷键/打印/可访问性）
│   └── lock.ts                 # 会员门控与导出限制
├── membership/
│   ├── logic/                  # auth/status 等核心逻辑
│   ├── ui/                     # 注册/登录/激活/购买 UI
│   ├── config.ts               # 套餐、配额、密钥版本
│   ├── types.ts                # 类型定义
│   └── AUTH_SECURITY_GUIDE.md  # 授权与安全详细说明
├── self-check.sh               # 发布前自检脚本
├── release.sh                  # 一键发布脚本
├── quick-deploy.sh             # 快速部署脚本
└── TEST.md                     # 回归测试清单
```

---

## 📌 注意事项

- 会员状态与配额目前主要在本地存储（插件场景可用，但不是强对抗安全模型）
- 若商业化规模扩大，建议尽快升级为“服务端签发 + 客户端验签/回执”模式
- 生产密钥不要写死在公开仓库，务必使用环境变量和私有配置管理

---

## 📄 License

MIT

---

## 🙏 致谢

- Obsidian
- marked
- DeepWrite（样式与阅读体验参考）
