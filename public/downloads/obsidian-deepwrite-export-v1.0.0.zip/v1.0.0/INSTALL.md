# DeepWrite Export 手动安装指南（面向新手）

这份文档会先解释你在做什么，再带你一步一步完成安装。

## 先理解 3 个概念

1. **Obsidian 是应用程序**
   - 就是你平时写笔记的软件。

2. **Vault 是你的笔记库文件夹**
   - 每个 Vault 都是一个独立目录，里面存放你的笔记与配置。

3. **插件安装在 Vault 内，不是安装在 Obsidian 应用目录**
   - Obsidian 只会扫描这个固定位置：
   - `.obsidian/plugins/deepwrite-export/`

## 为什么要放在隐藏目录 `.obsidian`

- `.obsidian` 是 Vault 的配置目录，保存插件、主题、快捷键等。
- 它是隐藏目录（以点号开头），Finder 默认不显示。
- 在 Finder 中按 `Cmd + Shift + .` 可以显示/隐藏。

## 安装前准备

下载并解压安装包后，确认至少有：

- `main.js`
- `manifest.json`
- `INSTALL.md`（本说明）

## 手动安装步骤（推荐按顺序完成）

1. 打开 Obsidian，进入你要安装插件的 Vault。
2. 打开该 Vault 的根目录（可在 Obsidian 里使用“在 Finder 中显示”）。
3. 在 Finder 中按 `Cmd + Shift + .`，显示隐藏目录。
4. 进入（或创建）目录：
   - `.obsidian/plugins/deepwrite-export/`
5. 复制 `main.js` 与 `manifest.json` 到该目录。
6. 回到 Obsidian：
   - 设置 → 第三方插件
   - 关闭安全模式（若尚未关闭）
   - 启用 **DeepWrite Export**

## 验证是否安装成功

启用后可验证：

- 设置中出现 DeepWrite Export
- 命令面板可搜索导出命令（例如导出当前笔记）
- 右键菜单可看到导出入口

## 新手常见问题

### Q1：我看不到 `.obsidian` 目录
A：在 Finder 按 `Cmd + Shift + .`，显示隐藏目录。

### Q2：复制完文件，插件列表里还是看不到
A：通常是路径放错。请确认路径是 **目标 Vault 内** 的：
`.obsidian/plugins/deepwrite-export/`

### Q3：多个 Vault 是否自动同步插件？
A：不会。插件按 Vault 生效，需要分别安装。

### Q4：升级版本要重装吗？
A：通常不需要。用新版本覆盖 `main.js` 和 `manifest.json` 即可。

## 升级插件

发布新版本后，重复复制：

- `main.js`
- `manifest.json`

然后在 Obsidian 中禁用后重新启用插件，或重启 Obsidian。
